"""
Configurações principais da aplicação.
"""

import os

from dotenv import load_dotenv

load_dotenv()

APP_NAME = "CHAT Bot APP O&M"
APP_VERSION = "0.1.0"

DATABASE_URL = os.getenv("DATABASE_URL", "")
API_KEY = os.getenv("API_KEY", "")
N8N_HEALTH_URL = os.getenv("N8N_HEALTH_URL", "http://n8n:5678/healthz/readiness")
ASSET_DOCUMENTS_DIR = os.getenv("ASSET_DOCUMENTS_DIR", "/app/storage/assets_documents")
