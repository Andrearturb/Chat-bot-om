# Correcao do bootstrap Keycloak - person name

## Sintoma

O servico `keycloak-bootstrap` encerrava com codigo 1 e imprimia:

`error-person-name-invalid-character`

## Causa

O bootstrap usava `O&M` como `lastName` dos usuarios DEV. No Keycloak 26, `firstName` e `lastName` sao validados pelo validador `person-name-prohibited-characters`; o caractere `&` nao e apropriado para esse campo e a Admin API rejeita a criacao/atualizacao.

## Correcao

O `lastName` dos usuarios DEV foi alterado de `O&M` para `OM` em:

- `keycloak/bootstrap-dev.sh`
- `keycloak/realm-export.json`

Isso nao muda realm, client, e-mail, senha, perfil da aplicacao ou permissoes.

## Como validar

Sem remover volumes:

```bash
docker compose down
docker compose up -d --build
```

Depois:

```bash
docker compose logs keycloak-bootstrap --no-color
docker compose ps -a
```

O bootstrap deve terminar com exit code 0 e registrar:

`Keycloak DEV sincronizado com as variaveis DEV_* do ambiente.`

Nunca use `docker compose down -v` neste teste.
