#!/usr/bin/env sh
# Sincroniza o Keycloak DEV já existente com o .env, sem apagar o volume.
# Útil quando DEV_*_EMAIL ou senhas são alterados depois da primeira inicialização.
set -eu

KC_URL="${KEYCLOAK_INTERNAL_URL:-http://keycloak:8080}"
REALM="${KEYCLOAK_REALM:-gentil-dev}"
KCADM="/opt/keycloak/bin/kcadm.sh"

attempt=0
until "$KCADM" config credentials --server "$KC_URL" --realm master \
  --user "$KEYCLOAK_ADMIN" --password "$KEYCLOAK_ADMIN_PASSWORD" >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 60 ]; then
    echo "Keycloak DEV não ficou disponível para bootstrap." >&2
    exit 1
  fi
  sleep 2
done

# Aguarda o realm importado existir.
attempt=0
until "$KCADM" get "realms/$REALM" >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 30 ]; then
    echo "Realm $REALM não encontrado." >&2
    exit 1
  fi
  sleep 1
done

ensure_user() {
  username="$1"; email="$2"; password="$3"; first="$4"
  user_id="$("$KCADM" get users -r "$REALM" -q "username=$username" --fields id --format csv --noquotes 2>/dev/null || true)"
  if [ -z "$user_id" ]; then
    user_id="$("$KCADM" create users -r "$REALM" -i \
      -s "username=$username" -s "email=$email" -s enabled=true -s emailVerified=true \
      -s "firstName=$first" -s 'lastName=OM')"
    user_id="$(printf '%s' "$user_id" | tr -d '"[:space:]')"
  else
    "$KCADM" update "users/$user_id" -r "$REALM" \
      -s "email=$email" -s enabled=true -s emailVerified=true \
      -s "firstName=$first" -s 'lastName=OM' >/dev/null
  fi
  "$KCADM" set-password -r "$REALM" --userid "$user_id" --new-password "$password" --temporary=false >/dev/null
}

ensure_user admin.om "$DEV_ADMIN_EMAIL" "$DEV_ADMIN_PASSWORD" Admin
ensure_user analista.om "$DEV_ANALYST_EMAIL" "$DEV_ANALYST_PASSWORD" Analista
ensure_user gerente.om "$DEV_MANAGER_EMAIL" "$DEV_MANAGER_PASSWORD" Gerente
ensure_user diretor.om "$DEV_DIRECTOR_EMAIL" "$DEV_DIRECTOR_PASSWORD" Diretor
ensure_user convidado.om "$DEV_GUEST_EMAIL" "$DEV_GUEST_PASSWORD" Convidado

client_uuid="$("$KCADM" get clients -r "$REALM" -q "clientId=$OIDC_CLIENT_ID" --fields id --format csv --noquotes 2>/dev/null || true)"
if [ -n "$client_uuid" ]; then
  "$KCADM" update "clients/$client_uuid" -r "$REALM" -s "secret=$OIDC_CLIENT_SECRET" >/dev/null
fi

echo "Keycloak DEV sincronizado com as variáveis DEV_* do ambiente."
